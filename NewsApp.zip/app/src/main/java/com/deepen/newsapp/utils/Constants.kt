package com.deepen.newsapp.utils

object Constants {
    const val apiKey: String = "9ac0ab4189fa4eb3a12e5c5f4d65449f"
    const val baseUrl = "https://newsapi.org/"
}